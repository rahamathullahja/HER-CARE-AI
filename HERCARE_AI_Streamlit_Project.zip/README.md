# HERCARE AI — Streamlit Academic Prototype

Features:
- Login/register with SQLite + bcrypt
- Menstrual cycle tracker
- Random Forest regression for estimated cycle length
- Wellness tracker and charts
- Optional pregnancy tracking
- Rule-based AI assistant for a safe offline demo
- Insights dashboard
- Privacy/data deletion page

## Windows setup

```powershell
cd C:\path\to\HERCARE_AI
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python ml\train_model.py
streamlit run app.py
```

Demo:
Email: demo@hercare.ai
Password: demo123

This is an academic prototype, not a medical device. ML results are estimates and
must not be used for diagnosis or treatment.
