from pathlib import Path
from datetime import date, timedelta, datetime
import sqlite3
import html

import bcrypt
import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
from sklearn.ensemble import RandomForestRegressor

BASE = Path(__file__).resolve().parent
DB_PATH = BASE / "hercare.db"
MODEL_PATH = BASE / "ml" / "cycle_model.joblib"

st.set_page_config(
    page_title="HERCARE AI",
    page_icon="🌸",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------- Styling ----------
st.markdown("""
<style>
.block-container { padding-top: 1.4rem; max-width: 1500px; }
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #fbf7ff 0%, #f5efff 100%);
}
.hero {
    padding: 24px 28px;
    border-radius: 24px;
    background: linear-gradient(135deg, #fff7fb, #f1ebff);
    border: 1px solid #eadfff;
}
.card {
    padding: 18px;
    border-radius: 18px;
    background: white;
    border: 1px solid #eee7ff;
    box-shadow: 0 5px 22px rgba(80,45,140,.07);
    min-height: 125px;
}
.small { color: #77748a; font-size: .9rem; }
.metric { font-size: 1.65rem; font-weight: 700; color: #25213a; }
.ai {
    padding: 18px;
    border-radius: 18px;
    background: linear-gradient(135deg, #f7f2ff, #fff5fb);
    border: 1px solid #e9dcff;
}
.privacy {
    padding: 18px;
    border-radius: 18px;
    background: #faf8ff;
    border: 1px solid #e8e0fa;
}
</style>
""", unsafe_allow_html=True)


# ---------- Database ----------
def db():
    return sqlite3.connect(DB_PATH, check_same_thread=False)


def init_db():
    con = db()
    cur = con.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash BLOB NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS periods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            start_date TEXT NOT NULL,
            end_date TEXT NOT NULL,
            flow INTEGER NOT NULL,
            pain INTEGER NOT NULL,
            symptoms TEXT,
            created_at TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS wellness (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            day TEXT NOT NULL,
            sleep REAL,
            water REAL,
            exercise REAL,
            stress INTEGER,
            mood INTEGER,
            created_at TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS pregnancy (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            lmp TEXT NOT NULL,
            due_date TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    con.commit()

    cur.execute("SELECT id FROM users WHERE email=?", ("demo@hercare.ai",))
    if cur.fetchone() is None:
        pw = bcrypt.hashpw(b"demo123", bcrypt.gensalt())
        cur.execute(
            "INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)",
            ("Jabira", "demo@hercare.ai", pw, datetime.now().isoformat())
        )
        con.commit()

    con.close()


init_db()


def get_user(email):
    con = db()
    row = con.execute(
        "SELECT id,name,email,password_hash FROM users WHERE email=?",
        (email.lower().strip(),)
    ).fetchone()
    con.close()
    return row


def create_user(name, email, password):
    con = db()
    try:
        pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        con.execute(
            "INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)",
            (name.strip(), email.lower().strip(), pw, datetime.now().isoformat())
        )
        con.commit()
        return True, "Account created."
    except sqlite3.IntegrityError:
        return False, "An account with that email already exists."
    finally:
        con.close()


def verify_user(email, password):
    row = get_user(email)
    if not row:
        return None
    try:
        valid = bcrypt.checkpw(password.encode(), row[3])
    except Exception:
        valid = False
    return row if valid else None


def periods_df(user_id):
    con = db()
    df = pd.read_sql_query(
        """SELECT id,start_date,end_date,flow,pain,symptoms
           FROM periods WHERE user_id=? ORDER BY start_date DESC""",
        con, params=(user_id,)
    )
    con.close()
    return df


def wellness_df(user_id):
    con = db()
    df = pd.read_sql_query(
        """SELECT day,sleep,water,exercise,stress,mood
           FROM wellness WHERE user_id=? ORDER BY day""",
        con, params=(user_id,)
    )
    con.close()
    return df


def latest_pregnancy(user_id):
    con = db()
    row = con.execute(
        """SELECT lmp,due_date FROM pregnancy
           WHERE user_id=? ORDER BY id DESC LIMIT 1""",
        (user_id,)
    ).fetchone()
    con.close()
    return row


# ---------- ML ----------
@st.cache_resource
def load_model():
    if MODEL_PATH.exists():
        try:
            import joblib
            return joblib.load(MODEL_PATH)
        except Exception:
            pass

    # Fallback model so the app can run before train_model.py is executed.
    rng = np.random.default_rng(42)
    X, y = [], []

    for _ in range(500):
        cycles = np.clip(rng.normal(29, 2.5, 4), 21, 40)
        avg = cycles.mean()
        var = cycles.std()
        duration = rng.integers(3, 8)
        pain = rng.integers(0, 8)
        flow = rng.integers(1, 4)
        target = np.clip(
            .15*cycles[0] + .20*cycles[1] +
            .25*cycles[2] + .40*cycles[3] +
            rng.normal(0, 1.2), 21, 40
        )
        X.append([*cycles, avg, var, duration, pain, flow])
        y.append(target)

    model = RandomForestRegressor(
        n_estimators=200,
        random_state=42,
        max_depth=8,
        min_samples_leaf=3
    )
    model.fit(X, y)
    return model


def cycle_features(df):
    if df.empty:
        return None

    d = df.copy()
    d["start_date"] = pd.to_datetime(d["start_date"])
    d["end_date"] = pd.to_datetime(d["end_date"])
    d = d.sort_values("start_date")

    d["duration"] = (d["end_date"] - d["start_date"]).dt.days + 1
    d["cycle_length"] = d["start_date"].diff().dt.days

    lengths = d["cycle_length"].dropna().tolist()
    if not lengths:
        return None

    if len(lengths) >= 4:
        last4 = lengths[-4:]
    else:
        mean = float(np.mean(lengths))
        last4 = ([mean] * (4 - len(lengths))) + lengths

    return {
        "cycle_1": last4[0],
        "cycle_2": last4[1],
        "cycle_3": last4[2],
        "cycle_4": last4[3],
        "average_cycle": float(np.mean(last4)),
        "cycle_variability": float(np.std(last4)),
        "period_duration": float(d["duration"].tail(4).mean()),
        "average_pain": float(d["pain"].tail(4).mean()),
        "flow_level": float(d["flow"].tail(4).mean()),
        "latest_start": d["start_date"].iloc[-1],
        "record_count": len(lengths)
    }


def predict_next_cycle(df):
    features = cycle_features(df)
    if not features:
        return None, None

    model = load_model()

    X = [[
        features["cycle_1"],
        features["cycle_2"],
        features["cycle_3"],
        features["cycle_4"],
        features["average_cycle"],
        features["cycle_variability"],
        features["period_duration"],
        features["average_pain"],
        features["flow_level"]
    ]]

    prediction = float(model.predict(X)[0])
    prediction = float(np.clip(prediction, 21, 40))

    return prediction, features


# ---------- Login ----------
if "user" not in st.session_state:
    st.session_state.user = None

if st.session_state.user is None:

    st.markdown("""
    <div class="hero">
        <h1>🌸 HERCARE AI</h1>
        <p style="font-size:1.1rem">
        Your privacy-first AI health companion
        </p>
    </div>
    """, unsafe_allow_html=True)

    login_tab, register_tab = st.tabs(["Login", "Create Account"])

    with login_tab:
        st.subheader("Welcome back")

        email = st.text_input(
            "Email",
            value="demo@hercare.ai"
        )

        password = st.text_input(
            "Password",
            type="password",
            value="demo123"
        )

        if st.button(
            "Login",
            type="primary",
            use_container_width=True
        ):
            user = verify_user(email, password)

            if user:
                st.session_state.user = {
                    "id": user[0],
                    "name": user[1],
                    "email": user[2]
                }
                st.rerun()
            else:
                st.error("Invalid email or password.")

        st.info("Demo: demo@hercare.ai / demo123")

    with register_tab:
        name = st.text_input("Name")
        email2 = st.text_input("Email", key="register_email")
        p1 = st.text_input("Password", type="password")
        p2 = st.text_input("Confirm password", type="password")

        if st.button(
            "Create Account",
            use_container_width=True
        ):
            if not name or not email2 or not p1:
                st.warning("Complete all fields.")
            elif p1 != p2:
                st.warning("Passwords do not match.")
            elif len(p1) < 6:
                st.warning("Password should contain at least 6 characters.")
            else:
                ok, msg = create_user(name, email2, p1)
                (st.success if ok else st.error)(msg)

    st.stop()


# ---------- Main navigation ----------
user = st.session_state.user

with st.sidebar:
    st.markdown("## 🌸 HERCARE AI")
    st.caption("Your Health Companion")

    page = st.radio(
        "Navigation",
        [
            "Dashboard",
            "Period Tracker",
            "Wellness",
            "Pregnancy Care",
            "AI Assistant",
            "Insights",
            "Privacy & Security"
        ]
    )

    st.divider()
    st.caption(f"Signed in as **{user['name']}**")

    if st.button("Logout", use_container_width=True):
        st.session_state.user = None
        st.rerun()


# ---------- Dashboard ----------
if page == "Dashboard":

    periods = periods_df(user["id"])
    wellness = wellness_df(user["id"])
    pregnancy = latest_pregnancy(user["id"])

    st.markdown(
        f"""
        <div class="hero">
            <h1>👋 Good Morning, {html.escape(user['name'])}!</h1>
            <p>Here's your personalized health overview.</p>
        </div>
        """,
        unsafe_allow_html=True
    )

    prediction, features = predict_next_cycle(periods)

    c1, c2, c3, c4 = st.columns(4)

    with c1:
        st.markdown(
            """
            <div class="card">
                <div class="small">🩸 PERIOD</div>
                <div class="metric">Cycle Tracking</div>
                <div class="small">ML prediction enabled</div>
            </div>
            """,
            unsafe_allow_html=True
        )

        if prediction and features:
            next_date = (
                features["latest_start"] +
                pd.Timedelta(days=round(prediction))
            )
            st.caption(
                f"Estimated next period: {next_date.strftime('%d %b %Y')}"
            )
        else:
            st.caption("Add period records to begin.")

    with c2:
        sleep = wellness["sleep"].tail(7).mean() if not wellness.empty else 0

        st.markdown(
            f"""
            <div class="card">
                <div class="small">🧘 WELLNESS</div>
                <div class="metric">{sleep:.1f} h</div>
                <div class="small">Recent average sleep</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with c3:
        if pregnancy:
            lmp = pd.to_datetime(pregnancy[0]).date()
            due = pd.to_datetime(pregnancy[1]).date()
            week = max(0, (date.today() - lmp).days // 7)

            st.markdown(
                f"""
                <div class="card">
                    <div class="small">🤰 PREGNANCY</div>
                    <div class="metric">Week {week}</div>
                    <div class="small">Due: {due}</div>
                </div>
                """,
                unsafe_allow_html=True
            )
        else:
            st.markdown(
                """
                <div class="card">
                    <div class="small">🤰 PREGNANCY</div>
                    <div class="metric">Optional</div>
                    <div class="small">No pregnancy record</div>
                </div>
                """,
                unsafe_allow_html=True
            )

    with c4:
        symptom_count = (
            0 if periods.empty
            else periods["symptoms"].fillna("").str.len().gt(0).sum()
        )

        st.markdown(
            f"""
            <div class="card">
                <div class="small">🩺 SYMPTOMS</div>
                <div class="metric">{symptom_count}</div>
                <div class="small">Entries with symptoms</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.write("")

    left, right = st.columns([2, 1])

    with left:
        st.subheader("Your Cycle Overview")

        if not periods.empty:
            chart = periods.copy()
            chart["start_date"] = pd.to_datetime(chart["start_date"])
            chart = chart.sort_values("start_date")
            chart["cycle_length"] = chart["start_date"].diff().dt.days
            chart = chart.dropna(subset=["cycle_length"])

            if not chart.empty:
                fig = px.line(
                    chart,
                    x="start_date",
                    y="cycle_length",
                    markers=True,
                    labels={
                        "cycle_length": "Cycle length (days)",
                        "start_date": "Period start"
                    }
                )
                fig.update_layout(height=300)
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Add more period records to see the cycle chart.")
        else:
            st.info("Start by adding your first period record.")

        st.markdown(
            """
            <div class="ai">
                <b>🤖 AI Insight</b><br>
                Track more records to build a personalized pattern.
                The ML estimate is an educational prediction, not a diagnosis.
            </div>
            """,
            unsafe_allow_html=True
        )

    with right:
        st.subheader("Today's Reminders")
        st.checkbox("💧 Drink water")
        st.checkbox("🚶 30 min walk")
        st.checkbox("📝 Record symptoms")
        st.checkbox("😴 Track sleep")


# ---------- Period Tracker ----------
elif page == "Period Tracker":

    st.title("🩸 Period Tracker")
    st.write(
        "Record menstrual information and view the ML-based cycle estimate."
    )

    with st.form("period_form"):

        start = st.date_input(
            "Period start date",
            value=date.today()
        )

        end = st.date_input(
            "Period end date",
            value=date.today()
        )

        flow = st.slider(
            "Flow level",
            1,
            3,
            2,
            help="1 = low, 2 = medium, 3 = high"
        )

        pain = st.slider(
            "Pain level",
            0,
            10,
            2
        )

        symptoms = st.multiselect(
            "Symptoms",
            [
                "Cramps",
                "Headache",
                "Fatigue",
                "Bloating",
                "Back pain",
                "Mood changes",
                "Nausea"
            ]
        )

        save = st.form_submit_button(
            "Save Period Record",
            type="primary"
        )

    if save:

        if end < start:
            st.error("End date cannot be before start date.")
        else:

            con = db()

            con.execute(
                """
                INSERT INTO periods
                (user_id,start_date,end_date,flow,pain,symptoms,created_at)
                VALUES(?,?,?,?,?,?,?)
                """,
                (
                    user["id"],
                    start.isoformat(),
                    end.isoformat(),
                    flow,
                    pain,
                    ", ".join(symptoms),
                    datetime.now().isoformat()
                )
            )

            con.commit()
            con.close()

            st.success("Period record saved.")
            st.rerun()

    periods = periods_df(user["id"])

    st.subheader("Your Records")

    if not periods.empty:

        st.dataframe(
            periods,
            use_container_width=True,
            hide_index=True
        )

        prediction, features = predict_next_cycle(periods)

        if prediction and features:

            next_date = (
                features["latest_start"] +
                pd.Timedelta(days=round(prediction))
            )

            lower = next_date - pd.Timedelta(days=1)
            upper = next_date + pd.Timedelta(days=1)

            st.markdown(
                f"""
                <div class="ai">
                    <h3>🔮 ML Prediction</h3>
                    <b>Estimated next cycle:</b>
                    {prediction:.1f} days
                    <br><br>
                    <b>Estimated next-period window:</b>
                    {lower.strftime('%d %b %Y')}
                    –
                    {upper.strftime('%d %b %Y')}
                    <br><br>
                    <span class="small">
                    Based on recorded cycle history. This is an estimate,
                    not a medical diagnosis.
                    </span>
                </div>
                """,
                unsafe_allow_html=True
            )


# ---------- Wellness ----------
elif page == "Wellness":

    st.title("🧘 Wellness Tracker")

    with st.form("wellness_form"):

        day = st.date_input(
            "Date",
            value=date.today()
        )

        sleep = st.number_input(
            "Sleep (hours)",
            0.0, 24.0, 7.0, 0.5
        )

        water = st.number_input(
            "Water (litres)",
            0.0, 10.0, 2.0, 0.1
        )

        exercise = st.number_input(
            "Exercise (minutes)",
            0.0, 300.0, 30.0, 5.0
        )

        stress = st.slider(
            "Stress",
            1, 10, 4
        )

        mood = st.slider(
            "Mood",
            1, 10, 7
        )

        save = st.form_submit_button(
            "Save Wellness Record",
            type="primary"
        )

    if save:

        con = db()

        con.execute(
            """
            INSERT INTO wellness
            (user_id,day,sleep,water,exercise,stress,mood,created_at)
            VALUES(?,?,?,?,?,?,?,?)
            """,
            (
                user["id"],
                day.isoformat(),
                sleep,
                water,
                exercise,
                stress,
                mood,
                datetime.now().isoformat()
            )
        )

        con.commit()
        con.close()

        st.success("Wellness record saved.")
        st.rerun()

    wellness = wellness_df(user["id"])

    if not wellness.empty:

        wellness["day"] = pd.to_datetime(wellness["day"])

        fig = px.line(
            wellness,
            x="day",
            y=["sleep", "water", "exercise"],
            markers=True,
            title="Wellness Trends"
        )

        fig.update_layout(height=380)

        st.plotly_chart(
            fig,
            use_container_width=True
        )

        st.dataframe(
            wellness.sort_values("day", ascending=False),
            use_container_width=True,
            hide_index=True
        )


# ---------- Pregnancy ----------
elif page == "Pregnancy Care":

    st.title("🤰 Pregnancy Care")

    st.info(
        "This module provides tracking and educational information only. "
        "It does not replace prenatal care or professional medical advice."
    )

    with st.form("pregnancy_form"):

        lmp = st.date_input(
            "Last menstrual period (LMP)",
            value=date.today() - timedelta(days=84)
        )

        save = st.form_submit_button(
            "Save Pregnancy Information",
            type="primary"
        )

    if save:

        due = lmp + timedelta(days=280)

        con = db()

        con.execute(
            """
            INSERT INTO pregnancy
            (user_id,lmp,due_date,created_at)
            VALUES(?,?,?,?)
            """,
            (
                user["id"],
                lmp.isoformat(),
                due.isoformat(),
                datetime.now().isoformat()
            )
        )

        con.commit()
        con.close()

        st.success("Pregnancy information saved.")
        st.rerun()

    pregnancy = latest_pregnancy(user["id"])

    if pregnancy:

        lmp = pd.to_datetime(pregnancy[0]).date()
        due = pd.to_datetime(pregnancy[1]).date()

        week = max(
            0,
            (date.today() - lmp).days // 7
        )

        c1, c2 = st.columns(2)

        c1.metric(
            "Estimated Pregnancy Week",
            f"Week {week}"
        )

        c2.metric(
            "Estimated Due Date",
            due.strftime("%d %B %Y")
        )

        st.markdown(
            """
            <div class="ai">
                <b>📚 Weekly educational guide</b><br>
                Use this section for medically reviewed general educational
                information appropriate to the pregnancy week.
            </div>
            """,
            unsafe_allow_html=True
        )


# ---------- AI Assistant ----------
elif page == "AI Assistant":

    st.title("🤖 HERCARE AI Assistant")

    st.caption(
        "General health-information assistant for the academic prototype."
    )

    if "chat" not in st.session_state:
        st.session_state.chat = []

    for role, message in st.session_state.chat:
        with st.chat_message(role):
            st.write(message)

    prompt = st.chat_input(
        "Ask a general health-tracking question..."
    )

    if prompt:

        st.session_state.chat.append(
            ("user", prompt)
        )

        low = prompt.lower()

        urgent_terms = [
            "emergency",
            "severe bleeding",
            "fainting",
            "can't breathe",
            "chest pain"
        ]

        if any(x in low for x in urgent_terms):

            reply = (
                "Those symptoms can require urgent medical attention. "
                "Please contact local emergency services or a qualified "
                "healthcare professional now."
            )

        elif any(
            x in low for x in
            ["period", "cycle", "menstrual"]
        ):

            reply = (
                "I can help you record cycle information and explain the "
                "app's prediction features. Cycle estimates can be inaccurate, "
                "especially when cycles are irregular or there are few records."
            )

        elif any(
            x in low for x in
            ["pregnancy", "pregnant"]
        ):

            reply = (
                "I can help track pregnancy dates and provide general "
                "educational information. Questions affecting pregnancy care "
                "should be discussed with a healthcare professional."
            )

        elif any(
            x in low for x in
            ["stress", "sleep", "water", "wellness", "exercise"]
        ):

            reply = (
                "You can record sleep, hydration, exercise, stress and mood "
                "in the Wellness section. HERCARE AI can summarize changes "
                "compared with your recorded pattern."
            )

        else:

            reply = (
                "I can help you understand information recorded in HERCARE AI, "
                "including cycle tracking, wellness trends and general "
                "educational information. I cannot diagnose a medical condition."
            )

        st.session_state.chat.append(
            ("assistant", reply)
        )

        st.rerun()


# ---------- Insights ----------
elif page == "Insights":

    st.title("📊 Personalized Insights")

    periods = periods_df(user["id"])
    wellness = wellness_df(user["id"])

    if periods.empty:

        st.info(
            "Add period records to generate cycle insights."
        )

    else:

        features = cycle_features(periods)

        if features:

            a, b, c = st.columns(3)

            a.metric(
                "Average Cycle",
                f"{features['average_cycle']:.1f} days"
            )

            b.metric(
                "Cycle Variability",
                f"{features['cycle_variability']:.1f} days"
            )

            c.metric(
                "Recorded Cycles",
                str(features["record_count"])
            )

        chart = periods.copy()

        chart["start_date"] = pd.to_datetime(
            chart["start_date"]
        )

        chart = chart.sort_values("start_date")

        chart["cycle_length"] = (
            chart["start_date"].diff().dt.days
        )

        chart = chart.dropna(
            subset=["cycle_length"]
        )

        if not chart.empty:

            fig = px.bar(
                chart,
                x="start_date",
                y="cycle_length",
                title="Recorded Cycle Lengths"
            )

            st.plotly_chart(
                fig,
                use_container_width=True
            )

    if not wellness.empty:

        st.subheader("Wellness Summary")

        st.dataframe(
            wellness.describe().round(2),
            use_container_width=True
        )


# ---------- Privacy ----------
elif page == "Privacy & Security":

    st.title("🔐 Privacy & Security")

    st.markdown(
        """
        <div class="privacy">
            <h3>Your Data, Your Control</h3>
            <ul>
                <li>Passwords are stored using bcrypt hashing.</li>
                <li>Health records are associated with the authenticated account.</li>
                <li>The academic prototype stores data locally in SQLite.</li>
                <li>A production version should provide export and deletion controls.</li>
                <li>Do not use identifiable real health records in the demo dataset.</li>
            </ul>
        </div>
        """,
        unsafe_allow_html=True
    )

    st.warning(
        "For real deployment, health data requires formal privacy, security, "
        "clinical and regulatory review. This is an academic prototype."
    )

    if st.button(
        "Delete My Local Records",
        type="secondary"
    ):

        con = db()

        con.execute(
            "DELETE FROM periods WHERE user_id=?",
            (user["id"],)
        )

        con.execute(
            "DELETE FROM wellness WHERE user_id=?",
            (user["id"],)
        )

        con.execute(
            "DELETE FROM pregnancy WHERE user_id=?",
            (user["id"],)
        )

        con.commit()
        con.close()

        st.success(
            "Your local prototype records were deleted."
        )

        st.rerun()
