from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib

# Synthetic educational data only.
# For research, use properly consented and de-identified data.
rng = np.random.default_rng(42)
rows = []

for _ in range(800):
    c1 = int(np.clip(rng.normal(29, 3), 21, 40))
    c2 = int(np.clip(rng.normal(c1, 2), 21, 40))
    c3 = int(np.clip(rng.normal(c2, 2), 21, 40))
    c4 = int(np.clip(rng.normal(c3, 2), 21, 40))
    cycles = [c1, c2, c3, c4]
    avg = np.mean(cycles)
    variability = np.std(cycles)
    duration = int(np.clip(rng.normal(5, 1), 2, 8))
    pain = int(rng.integers(0, 8))
    flow = int(rng.integers(1, 4))

    target = np.clip(
        0.15*c1 + 0.20*c2 + 0.25*c3 + 0.40*c4 + rng.normal(0, 1.2),
        21, 40
    )
    rows.append([c1,c2,c3,c4,avg,variability,duration,pain,flow,target])

columns = [
    "cycle_1","cycle_2","cycle_3","cycle_4",
    "average_cycle","cycle_variability","period_duration",
    "average_pain","flow_level","target_next_cycle"
]
df = pd.DataFrame(rows, columns=columns)

X = df.drop(columns="target_next_cycle")
y = df["target_next_cycle"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

model = RandomForestRegressor(
    n_estimators=250,
    random_state=42,
    max_depth=8,
    min_samples_leaf=3
)
model.fit(X_train, y_train)

pred = model.predict(X_test)
mae = mean_absolute_error(y_test, pred)
rmse = np.sqrt(mean_squared_error(y_test, pred))
r2 = r2_score(y_test, pred)

out = Path(__file__).resolve().parent / "cycle_model.joblib"
joblib.dump(model, out)

print("Model saved:", out)
print(f"MAE: {mae:.3f}")
print(f"RMSE: {rmse:.3f}")
print(f"R2: {r2:.3f}")
